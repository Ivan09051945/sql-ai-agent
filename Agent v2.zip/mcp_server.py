from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def root():
    return {"message": "MCP Server is running", "status": "healthy"}

@app.get("/tools")
def get_tools():
    return [{"name": "sql_query", "description": "Генерация SQL-запросов"}]
