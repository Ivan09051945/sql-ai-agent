sql
CREATE TABLE IF NOT EXISTS employees (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    department VARCHAR(50),
    salary DECIMAL(10, 2),
    hire_date DATE,
    is_active BOOLEAN DEFAULT true
);

CREATE TABLE IF NOT EXISTS orders (
    order_id SERIAL PRIMARY KEY,
    employee_id INTEGER REFERENCES employees(id),
    order_date DATE NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_amount DECIMAL(12, 2),
    status VARCHAR(20) DEFAULT 'pending'
);

INSERT INTO employees (first_name, last_name, email, department, salary, hire_date) VALUES
('Иван', 'Петров', 'ivan.petrov@company.com', 'IT', 75000.00, '2020-03-15'),
('Мария', 'Сидорова', 'maria.sidorova@company.com', 'HR', 65000.00, '2019-07-22'),
('Алексей', 'Козлов', 'alexey.kozlov@company.com', 'Sales', 80000.00, '2021-01-10'),
('Ольга', 'Николаева', 'olga.nikolaeva@company.com', 'IT', 72000.00, '2022-05-30'),
('Дмитрий', 'Васильев', 'dmitry.vasiliev@company.com', 'Finance', 90000.00, '2018-11-05');

INSERT INTO orders (employee_id, order_date, product_name, quantity, unit_price, total_amount, status) VALUES
(1, '2024-01-15', 'Ноутбук Dell XPS', 2, 1200.00, 2400.00, 'completed'),
(3, '2024-01-16', 'Кресло офисное', 5, 250.00, 1250.00, 'completed'),
(1, '2024-01-17', 'Монитор 27"', 3, 350.00, 1050.00, 'pending'),
(4, '2024-01-18', 'Клавиатура', 10, 120.00, 1200.00, 'shipped'),
(3, '2024-01-19', 'Смартфон', 4, 800.00, 3200.00, 'completed');
