from sqlalchemy import create_engine, text
import os

class DatabaseManager:
    def __init__(self):
        self.database_url = os.getenv(
            "DATABASE_URL",
            "postgresql://admin:admin123@postgres:5432/testdb"
        )
        self.engine = create_engine(self.database_url)
    
    def get_tables(self):
        with self.engine.connect() as conn:
            result = conn.execute(text("""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = 'public'
                ORDER BY table_name;
            """))
            return [row[0] for row in result.fetchall()]
    
    def execute_sql(self, sql_query: str, limit: int = 100):
        # Убираем пробелы и приводим к нижнему регистру для проверки
        sql_lower = sql_query.strip().lower()
        
        # Проверяем, что это SELECT запрос
        if not sql_lower.startswith('select'):
            return {"success": False, "error": "Только SELECT запросы разрешены"}
        
        # Добавляем LIMIT если его нет
        if 'limit' not in sql_lower:
            # Убираем точку с запятой если есть, добавляем LIMIT
            sql_query = sql_query.rstrip(';')
            sql_query = f"{sql_query} LIMIT {limit};"
        
        try:
            with self.engine.connect() as conn:
                result = conn.execute(text(sql_query))
                rows = result.fetchall()
                columns = result.keys()
                
                return {
                    "success": True,
                    "columns": list(columns),
                    "data": [dict(zip(columns, row)) for row in rows],
                    "row_count": len(rows),
                    "query": sql_query
                }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "query": sql_query
            }

# Создаём глобальный экземпляр менеджера
db_manager = DatabaseManager()

