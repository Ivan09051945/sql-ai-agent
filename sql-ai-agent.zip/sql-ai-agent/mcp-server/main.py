from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import database

app = FastAPI(title="MCP Server", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class SQLQuery(BaseModel):
    query: str
    limit: Optional[int] = 100

@app.get("/")
async def root():
    return {"message": "MCP Server работает"}

@app.get("/tables")
async def list_tables():
    return database.db_manager.get_tables()

@app.post("/query")
async def execute_query(sql_query: SQLQuery):
    return database.db_manager.execute_sql(sql_query.query, sql_query.limit)

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
