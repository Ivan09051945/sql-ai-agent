#!/bin/bash
echo "Ждем запуска Ollama..."
sleep 30
echo "Загружаем модель..."
docker exec ollama ollama pull llama3.2
echo "Готово!"
